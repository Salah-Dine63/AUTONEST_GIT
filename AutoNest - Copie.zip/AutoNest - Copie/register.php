<?php 

include 'connect.php';

if (isset($_POST['signIn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);  // Hash du mot de passe (recommandé de passer à password_hash en production)

    // Vérification de l'email et du mot de passe
    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        session_start();
        $row = $result->fetch_assoc();

        $_SESSION['email'] = $row['email'];
        $_SESSION['role'] = $row['role'];  // Enregistrement du rôle dans la session

        // Redirection en fonction du rôle
        if ($row['role'] == 'admin') {
            header("Location: admin_dashbord.php");  // Rediriger vers le tableau de bord admin
        } else {
            header("Location: dashbord.php");  // Rediriger vers le tableau de bord utilisateur
        }
        exit();
    } else {
        echo "Not Found, Incorrect Email or Password";
    }
}
?>
